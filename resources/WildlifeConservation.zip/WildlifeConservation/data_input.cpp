#include <iostream>
#include <stdio.h>
#include <time.h>
#include <cstdlib>

using namespace std;	



 
// Define Infinite (Using INT_MAX caused overflow problems)
#define INF 10000
 
struct Point
{
    double x;
    double y;
};
 
// Given three colinear points p, q, r, the function checks if
// point q lies on line segment 'pr'
bool onSegment(Point p, Point q, Point r)
{
    if (q.x <= max(p.x, r.x) && q.x >= min(p.x, r.x) &&
            q.y <= max(p.y, r.y) && q.y >= min(p.y, r.y))
        return true;
    return false;
}
 
// To find orientation of ordered triplet (p, q, r).
// The function returns following values
// 0 --> p, q and r are colinear
// 1 --> Clockwise
// 2 --> Counterclockwise
int orientation(Point p, Point q, Point r)
{
    int val = (q.y - p.y) * (r.x - q.x) -
              (q.x - p.x) * (r.y - q.y);
 
    if (val == 0) return 0;  // colinear
    return (val > 0)? 1: 2; // clock or counterclock wise
}
 
// The function that returns true if line segment 'p1q1'
// and 'p2q2' intersect.
bool doIntersect(Point p1, Point q1, Point p2, Point q2)
{
    // Find the four orientations needed for general and
    // special cases
    double o1 = orientation(p1, q1, p2);
    double o2 = orientation(p1, q1, q2);
    double o3 = orientation(p2, q2, p1);
    double o4 = orientation(p2, q2, q1);
 
    // General case
    if (o1 != o2 && o3 != o4)
        return true;
 
    // Special Cases
    // p1, q1 and p2 are colinear and p2 lies on segment p1q1
    if (o1 == 0 && onSegment(p1, p2, q1)) return true;
 
    // p1, q1 and p2 are colinear and q2 lies on segment p1q1
    if (o2 == 0 && onSegment(p1, q2, q1)) return true;
 
    // p2, q2 and p1 are colinear and p1 lies on segment p2q2
    if (o3 == 0 && onSegment(p2, p1, q2)) return true;
 
     // p2, q2 and q1 are colinear and q1 lies on segment p2q2
    if (o4 == 0 && onSegment(p2, q1, q2)) return true;
 
    return false; // Doesn't fall in any of the above cases
}
 
// Returns true if the point p lies inside the polygon[] with n vertices
bool isInside(Point polygon[], int n, Point p)
{
    // There must be at least 3 vertices in polygon[]
    if (n < 3)  return false;
 
    // Create a point for line segment from p to infinite
    Point extreme = {INF, p.y};
 
    // Count intersections of the above line with sides of polygon
    int count = 0, i = 0;
    do
    {
        int next = (i+1)%n;
 
        // Check if the line segment from 'p' to 'extreme' intersects
        // with the line segment from 'polygon[i]' to 'polygon[next]'
        if (doIntersect(polygon[i], polygon[next], p, extreme))
        {
            // If the point 'p' is colinear with line segment 'i-next',
            // then check if it lies on segment. If it lies, return true,
            // otherwise false
            if (orientation(polygon[i], p, polygon[next]) == 0)
               return onSegment(polygon[i], p, polygon[next]);
 
            count++;
        }
        i = next;
    } while (i != 0);
 
    // Return true if count is odd, false otherwise
    return count&1;  // Same as (count%2 == 1)
}

int main(){
	double ranLat[200], ranLng[200];
	FILE* data;
	int j =0, i=0;
	srand(time(NULL));
	data = fopen("ranthambore_lat.txt", "r");
	if(data){
		
		while(!feof(data)){
			fscanf(data, "%lf", &ranLat[j]);
			
			cout << j<< "	"<< ranLat[j]<< endl;
			j++;
		}
		fclose(data);
		//cout << ranLat[00];
	}
	else{ cout <<"data not read";}
	data = fopen("ranthambore_lng.txt", "r");
	j=0;
	if(data){
		
		do{
			fscanf(data, "%lf", &ranLng[j]);
			
			cout << j<< "	"<<  ranLng[j]<< endl;
			j++;
		}while(!feof(data));
		fclose(data);
		//cout << ranLat[00];
	}
	else{ cout <<"data not read";}	
	

    double polygon[100][2];
    struct Point polygon1[74];
    double maxi_x, mini_y, maxi_y, mini_x;
    maxi_x=  ranLat[0]; 
    mini_x=  ranLat[0];
    maxi_y=  ranLng[0];
    mini_y=  ranLng[0];
    for(int i=0; i<(j-1); i++){
    polygon[i][0] = ranLat[i];

    maxi_x = ranLat[i]>maxi_x?ranLat[i]:maxi_x;
    mini_x = ranLat[i]<mini_x?ranLat[i]:mini_x;
    polygon[i][1] = ranLng[i];
    maxi_y = ranLng[i]>maxi_y?ranLng[i]:maxi_y;
    mini_y = ranLng[i]<mini_y?ranLng[i]:mini_y;  
    polygon1[i].x = polygon[i][0];
    polygon1[i].y = polygon[i][1];  
    }
    cout << "maxi_x = "<<maxi_x<<" mini_x = "<<mini_x<<endl;
 	cout << "maxi_y = "<<maxi_y<<" mini_y = "<<mini_y<<endl;
    int n = j-1;
    // for(int i =0 ;i<n;i++){
    // 	cout << "testing  " << i << " " <<polygon1[i].x<< " " << polygon1[i].y<<endl;
    // }

    
 	double rect_x1, rect_x2, rect_y1, rect_y2;
 	struct Point randpt;
 	randpt = {25.911733,76.495743};
 	cout <<isInside(polygon1, n, randpt)<< endl;
 	double f;
 	for(int t=0 ;t<10;t++){
 		 f = (double)rand() / RAND_MAX;
 		rect_x1 = mini_x + f * (maxi_x - mini_x);
 		 f = (double)rand() / RAND_MAX;
 		rect_x2 = mini_x + f * (maxi_x - mini_x);
 		 f = (double)rand() / RAND_MAX;
 		rect_y1 = mini_y + f * (maxi_y - mini_y);
 		 f = (double)rand() / RAND_MAX;
 		rect_y2 = mini_y + f*(maxi_y - mini_y);
 		for(int pt =0; pt<10;pt++){
 			 f = (double)rand() / RAND_MAX;
	 		randpt.x = min(rect_x1 , rect_x2) + f * (max(rect_x2,rect_x1) - min(rect_x2,rect_x1));
	 		
	 		 f = (double)rand() / RAND_MAX;
	 		randpt.y = min(rect_y1 , rect_y2) + f * (max(rect_y2,rect_y1) - min(rect_y2,rect_y1));
	 		// cout << "("<<randpt.x<< " , " << randpt.y<<")"<<endl;
            printf("(%lf,%lf)\n", randpt.x, randpt.y);
 		}
 	}

	return 0;
	
}