# ChatApp
A client server based chat application built in Python
