import socket
import select
import sys
import json
import time
from thread import *
from datetime import datetime
from login import login, signup
from client_control import Client


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

IP_address = "localhost"
Port = 7800
with open('config.json') as config_file:
    configs = json.load(config_file)
    IP_address = configs["IP_address"]
    Port = configs["Port"]
server.bind((IP_address, Port)) 
server.listen(100)

print "Server created!!"


########################################################

def clientthread(conn, addr):
    conn.send("Welcome to ChatApp!\n")
    r_value = 0
    while True:
        conn.send("Do you want to login or signup?")
        message = conn.recv(1024)
        if len(message) == 0:
            r_value = 1
        elif message == "login":
            r_value = login(conn,addr)
        elif message == "signup":
            r_value = signup(conn,addr)        
        if r_value != 0:
            break

    if r_value == 1:
        conn.close()
        return
    curr_user = Client(r_value,conn,addr)
    r_value = curr_user.listener()
    if r_value == 0:
        print curr_user.username + " logged out"
    elif r_value == 1:
        print curr_user.username + " thread broken"
    del Client.instances[curr_user.username]
    del curr_user
    if r_value == 0:
        clientthread(conn,addr)

try:
    while True:
        conn, addr = server.accept()
        print addr[0] + " connected"
        start_new_thread(clientthread,(conn,addr))
except(KeyboardInterrupt, SystemExit):
    print "Closing Server Connection"
    try:
        conn.close()
    except NameError:
        pass
    server.close()
    sys.exit()

conn.close()
server.close()