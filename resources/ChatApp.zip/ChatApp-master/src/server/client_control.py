import re
import json
import time

users={}
offline_dump ={}

#Converts Unicode to ASCII
def convert(input):
    if isinstance(input, dict):
        return {convert(key): convert(value) for key, value in input.iteritems()}
    elif isinstance(input, list):
        return [convert(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input

def load_users():
    global users
    with open('users.json') as users_file:
        users = json.load(users_file)
        users = convert(users)

def load_msg_dump():
    global offline_dump
    with open('msg_dump.json') as msg_file:
        offline_dump = json.load(msg_file)
        offline_dump = convert(offline_dump)

class Client:
    instances={}
    def __init__(self, username,connection,address):
        self.username = username
        self.connection = connection
        self.address = address
        self.talking_to = "broadcast"
        Client.instances[username] = self

    def listener(self):
        self.print_msg_dump()
        while True:
            message = self.connection.recv(1024)
            if len(message)==0:
                self.logout_user()
                return 1
            elif message.startswith("\\"):
                r_value = self.process_command(message)
                if r_value:
                    return 0
            elif self.talking_to == "broadcast":
                self.broadcast(message)
            else:
                self.private_message(message)

    def print_msg_dump(self):
        load_msg_dump()
        new_message = "Offline messages:"
        if self.username in offline_dump.keys():
            user_msg_dump= offline_dump[self.username]
            new_message += "\n" + user_msg_dump
            del offline_dump[self.username]
            with open('msg_dump.json','w') as msg_file:
                json.dump(offline_dump,msg_file)
        else:
            new_message += "\nNo Pending Messages"
        self.message_self(new_message)

    def process_command(self,message):
        change_chat = re.compile(r'^\\(M|m)essage ')
        who_lasthr = re.compile(r'^\\(W|w)holasthr')
        broadcast = re.compile(r'^\\(B|b)roadcast')
        who_else = re.compile(r'^\\(W|w)hoelse')
        unblock = re.compile(r'^\\(U|u)nblock')
        logout = re.compile(r'^\\(L|l)ogout')
        block = re.compile(r'^\\(B|b)lock')
        if re.match(change_chat,message):
            new_recv = message[9:]
            self.change_chat(new_recv)
        elif re.match(broadcast,message):
            self.talking_to = "broadcast"
            self.message_self("Changed to broadcast mode\n")
        elif re.match(who_else,message):
            self.print_online()
        elif re.match(who_lasthr,message):
            self.print_online_lasthr()
        elif re.match(logout,message):
            self.logout_user()
            new_message = "Logged Out!!!\n"
            self.message_self(new_message)
            return 1
        elif re.match(block,message):
            user_to_block = message[7:]
            self.block_user(user_to_block)
        elif re.match(unblock,message):
            user_to_unblock = message[9:]
            self.unblock_user(user_to_unblock)
        else:
            new_message = "Command not recognized!!\n"
            self.message_self(new_message)
        return 0

    def logout_user(self):
        load_users()
        users[self.username]["lastLogoutTime"]=int(time.time())
        with open('users.json','w') as credsFile:
            json.dump(users,credsFile)
        
    def change_chat(self,new_recv):
        load_users()
        user_settings = users[self.username]
        if new_recv not in users.keys():
            new_message = "User does not exist.\n"
            self.message_self(new_message)
            return
        recv_settings = users[new_recv]
        if new_recv in user_settings["blockedList"]:
            new_message = ("You have blocked "+new_recv+\
                ". Unblock before trying to message.\n")
            self.message_self(new_message)
            return
        if self.username in recv_settings["blockedList"]:
            new_message = ("Cannot message "+new_recv+\
                ". You have been blocked.\n")
            self.message_self(new_message)
            return
        if new_recv in Client.instances:
            self.message_self("Now talking to "+new_recv+"\n")
        else:
            self.message_self("User Currently Not Online\n")
        self.talking_to = new_recv

    def print_online(self):
        new_message = "List of other Online Users:"
        for client in Client.instances:
            if client == self.username:
                continue
            other_cli = Client.instances[client]
            new_message += "\n"+other_cli.username
        self.message_self(new_message)

    def print_online_lasthr(self):
        load_users()
        new_message = "List of users online during last hour:"
        curr_time = int(time.time())
        for user in users:
            user_details = users[user]
            if user == self.username:
                continue
            if curr_time - user_details["lastLogoutTime"] < 3600 \
            or curr_time - user_details["lastLoginTime"] < 3600:
                new_message += "\n"+ user
        self.message_self(new_message)

    def block_user(self,user_to_block):
        load_users()
        user_settings = users[self.username]
        if user_to_block == self.username:
            new_message = "Cannot block yourself.\n"
            self.message_self(new_message)
            return
        if user_to_block not in users.keys():
            new_message = "User does not exist.\n"
            self.message_self(new_message)
            return
        if user_to_block in user_settings["blockedList"]:
            new_message = "User already blocked.\n"
            self.message_self(new_message)
            return
        users[self.username]["blockedList"].append(user_to_block)
        with open('users.json','w') as creds_file:
            json.dump(users,creds_file)

    def unblock_user(self,user_to_unblock):
        load_users()
        user_settings = users[self.username]
        if user_to_unblock not in users.keys():
            new_message = "User does not exist.\n"
            self.message_self(new_message)
            return
        if user_to_unblock not in user_settings["blockedList"]:
            new_message = "User not blocked.\n"
            self.message_self(new_message)
            return
        users[self.username]["blockedList"].remove(user_to_unblock)
        with open('users.json','w') as creds_file:
            json.dump(users,creds_file)
        
    def message_self(self,message):
        try:
            self.connection.send(message)
        except:
            self.connection.close()

    def private_message(self,message):
        message = "<Prv:"+self.username+">"+message
        if self.talking_to in Client.instances:
            recv_cli = Client.instances[self.talking_to]
            try:
                recv_cli.connection.send(message)
            except:
                recv_cli.connection.close()
                self.remove_client(recv_cli)
        else:
            load_msg_dump()
            if self.talking_to not in offline_dump:
                offline_dump[self.talking_to] = ""
            offline_dump[self.talking_to] += "\n"+ message
            with open('msg_dump.json','w') as msg_file:
                json.dump(offline_dump,msg_file)

    def broadcast(self,message):
        message = "<Brd:"+self.username+">"+message
        for client in Client.instances:
            if client == self.username:
                continue
            recv_cli = Client.instances[client]
            try:
                recv_cli.connection.send(message)
            except:
                recv_cli.connection.close()
                self.remove_client(recv_cli)

    def remove_client(self,client):
        if client in Client.instances:
            del Client.instances[client]
