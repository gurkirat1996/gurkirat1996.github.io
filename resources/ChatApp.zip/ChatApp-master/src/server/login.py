# from server import remove_conn
import json
import time
blocked_IP = {}
users={}

#Converts Unicode to ASCII
def convert(input):
    if isinstance(input, dict):
        return {convert(key): convert(value) for key, value in input.iteritems()}
    elif isinstance(input, list):
        return [convert(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input

def load_users():
    global users
    with open('users.json') as users_file:
        users = json.load(users_file)
        users = convert(users)

def send_message(message,connection):
    message = "<ChatApp>"+message+"\n"
    try:
        connection.send(message)
    except:
        connection.close()

#Login Handler Function
def login(conn,addr,attempts_left=3):
    #Checks if IP is blocked
    if addr[0] in blocked_IP:    
        blocked_time = blocked_IP[addr[0]]["lastFailedAttempt"] + 60 - int(time.time())
        if blocked_time > 0:
            message_to_send = "You are currently blocked. Try again in " + str(blocked_time) + " seconds."
            send_message(message_to_send,conn)
            return 1
        else:
            del blocked_IP[addr[0]]

    message=""
    username = ""
    password = ""
    if attempts_left==3:
        message_to_send = ("Welcome of Login Menu!\n"
        "Use \\exit anytime to return to previous menu.")
        send_message(message_to_send,conn)
    message_to_send = "Please enter username:"
    send_message(message_to_send,conn)
    while True:
        message = conn.recv(4096)
        if len(message) > 0:
            if message == "\\exit":
                return 0
            username = message
            break
        else:
            return 1
    
    message_to_send = "Please enter your password:"
    send_message(message_to_send,conn)
    while True:
        message = conn.recv(4096)
        if len(message) > 0:
            if message == "\\exit":
                return 0
            password = message
            break
        else:
            return 1

    load_users()
    if username in users:
        user_details = users[username]
        if user_details["lastLoginTime"] > user_details["lastLogoutTime"]:
            message_to_send = "User Already logged in!"
            send_message(message_to_send,conn)
            return 0
        if user_details["password"] == password:
            message_to_send = "Login successful."
            send_message(message_to_send,conn)
            users[username]["lastLoginTime"] = int(time.time())
            with open('users.json','w') as credsFile:
                json.dump(users,credsFile)    
            return username
        else:
            attempts_left -= 1
            if attempts_left > 0:
                message_to_send = ("Invalid Username and Password Combination\n"
                "Try Again (Attempts remaining: "+str(attempts_left)+")")
                send_message(message_to_send,conn)

                return login(conn,addr,attempts_left)
            else:
                message_to_send = "Attempts over, try again after 60 seconds"
                send_message(message_to_send,conn)
                blocked_IP[addr[0]]={}
                blocked_IP[addr[0]]["lastFailedAttempt"]= int(time.time())
                return 1

    else:
        attempts_left -= 1
        if attempts_left > 0:
            message_to_send = ("User not found. "
            "Please enter username again.(attempts remaining: "+ str(attempts_left)+")")
            send_message(message_to_send,conn)
            return login(conn,addr,attempts_left)
        else:
            message_to_send = "Attempts over, try again after 60 seconds"
            send_message(message_to_send,conn)
            blocked_IP[addr[0]]={}
            blocked_IP[addr[0]]["lastFailedAttempt"]= int(time.time())
            return 1


def create_user(username,password):
    load_users()
    users[username] = {}
    users[username]["password"] = password
    users[username]["lastLoginTime"] = int(time.time())
    users[username]["lastLogoutTime"] = 0
    users[username]["blockedList"]=[]
    with open('users.json','w') as credsFile:
        json.dump(users,credsFile)

def signup(conn,addr):
    message=""
    username = ""
    password = ""
    message_to_send = ("Welcome of Signup Menu!\n"
    "Use \\exit anytime to return to previous menu.\n"
    "Please enter a username:")
    send_message(message_to_send,conn)
    load_users()
    while True:
        message = conn.recv(4096)
        if len(message) > 0:
            username = message
            if message == "\\exit":
                return 0
            if username in users:
                message_to_send = "Username already taken, pick another username:"
                send_message(message_to_send,conn)
            else:
                break
        else:
            message_to_send = "Username cannot be blank! Enter a valid username:"
            send_message(message_to_send,conn)
        
    while True:
        message_to_send = "Please enter your password:"
        send_message(message_to_send,conn)

        while True:
            message = conn.recv(4096)
            if len(message) > 0:
                if message == "\\exit":
                    return 0
                password = message
                break
            else:
                message_to_send = "Password cannot be blank! Enter a valid password:"
                send_message(message_to_send,conn)
        
        message_to_send = "Confirm your password:"
        send_message(message_to_send,conn)

        while True:
            message = conn.recv(4096)
            if len(message) > 0:
                if message == "\\exit":
                    return 0
                password_copy = message
                break
            else:
                message_to_send = "Password cannot be blank! Enter a valid password:"
                send_message(message_to_send,conn)
        if password_copy != password:
            message_to_send = "Password Mismatch. Try Again!"
            send_message(message_to_send,conn)
        else:
            break
    create_user(username, password)
    message_to_send = "New User Created Successfully"
    send_message(message_to_send, conn)
    return username