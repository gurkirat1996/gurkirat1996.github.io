import socket
import select
import sys
import hashlib


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# if len(sys.argv) != 3:
#     print "Correct usage: script, IP address, port number"
#     exit()
# IP_address = str(sys.argv[1])
# Port = int(sys.argv[2])
IP_address = "localhost"
Port = 7800
server.connect((IP_address, Port))

passwordFlag = 0
user_running = True
try:
    while user_running:
        sockets_list = [sys.stdin, server]
        read_sockets,write_socket, error_socket = select.select(sockets_list, [], [])
        for socks in read_sockets:
            if socks == server:
                message = socks.recv(4096)
                passwordFlag = 0
                if len(message) ==0:
                    print "Server Disconnected!"
                    user_running = False
                    break
                elif message.find("password") != -1:
                    passwordFlag = 1
                print message

            else:
                message = sys.stdin.readline().rstrip('\n')
                # if passwordFlag ==1:
                    # message =   hashlib.md5(message.encode()).digest()
                server.send(message)
                if message == "\logout":
                    user_running = False
                    break
                screen_message = "<You>"+message+"\n"
                sys.stdout.write(screen_message)
                sys.stdout.flush()
except(KeyboardInterrupt, SystemExit):
    print "Closing Client Connection!"

server.close()
sys.exit()