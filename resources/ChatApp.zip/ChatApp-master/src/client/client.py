import socket
import select
import sys
import hashlib
import json

from string import printable
from curses import erasechar, wrapper
import curses
import re

PRINTABLE = map(ord,printable)

###Server Setup
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
IP_address = "localhost"
Port = 7800
with open('config.json') as config_file:
    configs = json.load(config_file)
    IP_address = configs["IP_address"]
    Port = configs["Port"]
server.connect((IP_address, Port))
user_running = True
password_flag = False
#########################################


####Client Screen Variables
screen_Y = 0
screen_X = 0
curr_x = 0
curr_y = 0
lines = []
max_lines = 0
##################

def display_prompt(stdscr):
    global curr_y, curr_x, screen_Y
    prompt = ">>> "
    stdscr.move((screen_Y-1),0)
    stdscr.clrtoeol()
    stdscr.addstr((screen_Y-1),0,prompt)
    curr_y, curr_x = stdscr.getyx()
    stdscr.refresh()

def read_char(stdscr):
    global curr_x, curr_y, server
    global user_running, password_flag
    ch = stdscr.getch()
    if ch == curses.KEY_ENTER or ch in (10,13):
        org_message = "".join(read_char.message)
        new_message = "<You>"+org_message
        if password_flag:
            new_message = "<You>"+ '*'*len(org_message)
        if org_message == "quit":
            user_running = False
            return
        server.send(org_message)
        print_line(stdscr,new_message)
        read_char.message=[]
        display_prompt(stdscr)
    elif ch == curses.KEY_BACKSPACE:
        if curr_x > 4:
            del read_char.message[-1]
            stdscr.move(curr_y,(curr_x-1))
            stdscr.clrtoeol()
            stdscr.refresh()
            curr_x -=1
    elif ch in PRINTABLE:
        read_char.message.append(chr(ch))
        stdscr.move(curr_y,curr_x)
        if password_flag:
            stdscr.addch(42)
        else:
            stdscr.addch(ch)
        curr_y, curr_x = stdscr.getyx()
        stdscr.refresh()

def print_line(stdscr,message):
    global lines, max_lines, screen_X, screen_Y
    global curr_y, curr_x
    msg_lines = message.splitlines()
    count_lines = len(msg_lines)
    if len(lines) + count_lines > max_lines:
        lines = lines[count_lines:]
        stdscr.clear()
        for i, line in enumerate(lines):
            stdscr.addstr(i,line)
    for msg_line in msg_lines:
        stdscr.addstr(len(lines),0,msg_line)
        lines.append(msg_line)
    stdscr.move(curr_y,curr_x)
    stdscr.refresh()

def read_server(stdscr,sock):
    global user_running, password_flag
    pass_msg = re.compile(r'^<ChatApp>.+password:$')
    message = sock.recv(4096)
    if len(message) == 0:
        new_message = "Server Disconnected!!"
        print_line(stdscr,new_message)
        user_running = False
    else:
        if re.match(pass_msg,message):
            password_flag = True
        else:
            password_flag = False
        print_line(stdscr,message)

def main(stdscr):
    global screen_Y, screen_X, max_lines
    screen_Y, screen_X = stdscr.getmaxyx()
    max_lines = (screen_Y-3)
    stdscr.clear()
    read_char.message = []
    sockets_list = [sys.stdin, server]
    display_prompt(stdscr)
    try:
        while user_running:
            r_socks, w_socks, e_socks = select.select(sockets_list, [], [])
            for sock in r_socks:
                if sock == server:
                    read_server(stdscr,sock)
                else:
                    read_char(stdscr)
    except(KeyboardInterrupt, SystemExit):
        new_message = "Closing Client Connection!"
        print_line(stdscr,new_message)

wrapper(main)

server.close()
sys.exit()